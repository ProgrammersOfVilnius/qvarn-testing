# A shell library for the shell-lib.yarn test.

implement()
{
    echo "$@"
}
