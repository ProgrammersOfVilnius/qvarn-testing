Logging
=======

Logging support: by default, no log file is written, it must be
requested explicitly by the user. The default log level is info.

