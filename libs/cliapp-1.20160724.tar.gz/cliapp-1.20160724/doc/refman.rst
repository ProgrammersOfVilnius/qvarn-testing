Reference manual
================

.. automodule:: cliapp
   :members:
   :undoc-members:
   :exclude-members: add_boolean_setting, add_bytesize_setting,
        add_choice_setting, add_integer_setting, add_string_list_setting,
        add_string_setting, config_files

