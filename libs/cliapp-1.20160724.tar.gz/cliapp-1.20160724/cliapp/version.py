__version__ = "1.20160724"
__version_info__ = (1, 20160724)
